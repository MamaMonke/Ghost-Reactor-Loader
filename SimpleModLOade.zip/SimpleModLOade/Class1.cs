﻿using System;
using BepInEx;
using UnityEngine;
using HarmonyLib;
using UnityEngine.SceneManagement;

namespace SimpleModLoader
{
    [BepInPlugin("MamaMonkeSTAFF.GSpatch", "Ghost Reactor Patcher", "0.0.2")]
    public class Class1 : BaseUnityPlugin
    {
        private bool isGhostReactorLoaded = false;
        private Scene? ghostReactorScene;
        private bool showGUI = true;

        void Awake()
        {
            Harmony harmony = new Harmony("Mamamonke");
            harmony.PatchAll();

            Debug.Log("Мод загружен");
        }

        void Update()
        {
            // Должна работать но на деле не нужная параша
            if (Input.GetKeyDown(KeyCode.F1))
            {
                showGUI = !showGUI;
            }
        }

        void OnGUI()
        {
            if (!showGUI) return;

            GUILayout.BeginArea(new Rect(10, 10, 200, 200));
            GUILayout.BeginVertical("box");

            GUILayout.Label("Ghost Reactor Loader");

            if (GUILayout.Button(isGhostReactorLoaded ? "Выгрузить Ghost Reactor" : "Загрузить Ghost Reactor"))
            {
                if (!isGhostReactorLoaded)
                {
                    LoadGhostReactor();
                }
                else
                {
                    UnloadGhostReactor();
                }
            }

            if (GUILayout.Button("Закрыть меню"))
            {
                showGUI = false;
            }

            GUILayout.EndVertical();
            GUILayout.EndArea();
        }

        void LoadGhostReactor()
        {
            try
            {
                bool sceneExists = false;
                for (int i = 0; i < SceneManager.sceneCountInBuildSettings; i++)
                {
                    string scenePath = SceneUtility.GetScenePathByBuildIndex(i);
                    string sceneName = System.IO.Path.GetFileNameWithoutExtension(scenePath);
                    if (sceneName == "GhostReactor")
                    {
                        sceneExists = true;
                        break;
                    }
                }

                if (sceneExists)
                {
                    SceneManager.LoadScene("GhostReactor", LoadSceneMode.Additive);
                    isGhostReactorLoaded = true;
                    ghostReactorScene = SceneManager.GetSceneByName("GhostReactor");
                    Debug.Log("Ghost Reactor загружен в режиме Additive!");
                }
                else
                {
                    Debug.LogError("Сцена не найдена");
                }
            }
            catch (Exception e)
            {
                Debug.LogError("Ошибка загрузки: " + e.Message);
            }
        }

        void UnloadGhostReactor()
        {
            try
            {
                if (ghostReactorScene.HasValue && ghostReactorScene.Value.IsValid())
                {
                    SceneManager.UnloadSceneAsync(ghostReactorScene.Value);
                }
                else
                {
                    Scene ghostScene = SceneManager.GetSceneByName("GhostReactor");
                    if (ghostScene.IsValid())
                    {
                        SceneManager.UnloadSceneAsync(ghostScene);
                    }
                }

                isGhostReactorLoaded = false;
                ghostReactorScene = null;
                Debug.Log("Ghost Reactor выгружен");
            }
            catch (Exception e)
            {
                Debug.LogError("Ошибка выгрузки: " + e.Message);
            }
        }
    }
}